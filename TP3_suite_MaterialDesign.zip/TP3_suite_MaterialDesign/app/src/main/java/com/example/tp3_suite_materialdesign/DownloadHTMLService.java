package com.example.tp3_suite_materialdesign;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadHTMLService extends Service {

    private ExecutorService executor;

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newSingleThreadExecutor();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ArrayList<String> urls = intent.getStringArrayListExtra("urls");
        ArrayList<String> names = new ArrayList<>();
        names.add("webPerso");
        names.add("linPerso");
        names.add("webEntre");
        names.add("linEntre");


        executor.execute(() -> {
            if (urls != null) {
                for (int i=0 ; i < 4 ; i++) {
                    Log.d("HtmlDownloadService", "Téléchargement de : " + urls.get(i));
                    downloadHtml(urls.get(i), names.get(i));
                }
            }

            Intent intentEnd = new Intent("DOWNLOAD_COMPLETE");
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intentEnd);
            Log.d("DOWNLOAD","Broadcast Envoyé");

            stopSelf();
        });
        return START_NOT_STICKY;
    }

    private void downloadHtml(String urlString, String fileName) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            InputStream input = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            StringBuilder html = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                html.append(line).append("\n");
            }

            File dir = new File(getFilesDir(), "pages_html");
            if (!dir.exists()) {
                dir.mkdirs();
            }

            File file = new File(dir, fileName + ".html");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(html.toString().getBytes());
            fos.close();
            if (file.exists()) {
                Log.d("DOWNLOAD", "Fichier téléchargé avec succès : " + file.getAbsolutePath());
            } else {
                Log.d("DOWNLOAD", "Le fichier n'a pas été téléchargé ou écrit : " + file.getAbsolutePath());
            }

        } catch (Exception e) {
            Log.e("HtmlDownloadService", "Erreur lors du téléchargement de " + urlString + " : " + e.getMessage(), e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
