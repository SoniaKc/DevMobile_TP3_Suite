package com.example.tp3_suite_materialdesign;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import java.io.File;

public class SummaryActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_summary);

        TextView infos = findViewById(R.id.tvResume);
        WebView webView = findViewById(R.id.webView);

        String nom = getIntent().getStringExtra("nom");
        String prenom = getIntent().getStringExtra("prenom");
        String webPerso = getIntent().getStringExtra("webPerso");
        String linPerso = getIntent().getStringExtra("linPerso");
        String webEntre = getIntent().getStringExtra("webEntre");
        String linEntre = getIntent().getStringExtra("linEntre");

        String summary = "Nom : " + nom + "\n\n" +
                "Prénom : " + prenom + "\n\n" +
                "Page web personnelle : \n" + webPerso + "\n\n" +
                "LinkedIn personnel : \n" + linPerso + "\n\n" +
                "Page web entreprise : \n" + webEntre + "\n\n" +
                "LinkedIn entreprise : \n" + linEntre;
        infos.setText(summary);

        File file = new File(getFilesDir(), "pages_html/webPerso.html");
        Uri fileUri = FileProvider.getUriForFile(this, "com.example.TP3_suite_MaterialDesign.provider", file);

        if (file.exists()) {
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl(fileUri.toString());
        }


    }
}
