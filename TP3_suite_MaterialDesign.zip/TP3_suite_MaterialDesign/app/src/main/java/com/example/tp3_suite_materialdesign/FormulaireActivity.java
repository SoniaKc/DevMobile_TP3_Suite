package com.example.tp3_suite_materialdesign;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class FormulaireActivity extends Activity {

    String FILENAME = "reponseFormulaire";
    String nom, prenom, webPerso, linPerso, webEntre, linEntre;
    BroadcastReceiver receiver;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_formulaire);


        Button annuler = findViewById(R.id.annuler);
        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(FormulaireActivity.this,FormulaireActivity.class);
                startActivity(intent);
            }
        });


        Button valider = findViewById(R.id.valider);
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                nom = ((EditText)findViewById(R.id.nom)).getText().toString();
                prenom = ((EditText)findViewById(R.id.prenom)).getText().toString();
                webPerso = ((EditText)findViewById(R.id.webPerso)).getText().toString();
                linPerso = ((EditText)findViewById(R.id.linPerso)).getText().toString();
                webEntre = ((EditText)findViewById(R.id.webEntre)).getText().toString();
                linEntre = ((EditText)findViewById(R.id.linEntre)).getText().toString();

                try {
                    FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
                    String donnees = nom + "\n" + prenom + "\n" + webPerso + "\n" + linPerso + "\n" + webEntre + "\n" + linEntre;
                    fos.write(donnees.getBytes());
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                Intent intent = new Intent(FormulaireActivity.this,DownloadHTMLService.class);
                ArrayList<String> urls = new ArrayList<>();
                urls.add(webPerso);
                urls.add(linPerso);
                urls.add(webEntre);
                urls.add(linEntre);

                intent.putStringArrayListExtra("urls",urls);
                startService(intent);
            }
        });



        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Log.d("FOMRMULAIRE","Broadcast reçu");

                Intent intentSummary = new Intent(FormulaireActivity.this, SummaryActivity.class);
                intentSummary.putExtra("nom", nom);
                intentSummary.putExtra("prenom", prenom);
                intentSummary.putExtra("webPerso", webPerso);
                intentSummary.putExtra("linPerso", linPerso);
                intentSummary.putExtra("webEntre", webEntre);
                intentSummary.putExtra("linEntre", linEntre);
                startActivity(intentSummary);

                Log.d("FOMULAIRE", "Intent envoyé à Summary");
            }
        };
    }


    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter("DOWNLOAD_COMPLETE");

        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);
    }


    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }
}
