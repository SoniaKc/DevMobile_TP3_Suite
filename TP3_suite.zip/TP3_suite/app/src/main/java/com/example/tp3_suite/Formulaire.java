package com.example.tp3_suite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Formulaire extends AppCompatActivity {

    String FILENAME = "reponseFormulaire";
    String nom, prenom, webPerso, linPerso, webEntreprise, linEntreprise;
    BroadcastReceiver receiver;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_formulaire);


        Button annuler = findViewById(R.id.annuler);
        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Formulaire.this,Formulaire.class);
                startActivity(intent);
            }
        });


        Button valider = findViewById(R.id.valider);
        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                nom = ((EditText)findViewById(R.id.nom)).getText().toString();
                prenom = ((EditText)findViewById(R.id.prenom)).getText().toString();
                webPerso = ((EditText)findViewById(R.id.webPerso)).getText().toString();
                linPerso = ((EditText)findViewById(R.id.linkedinPerso)).getText().toString();
                webEntreprise = ((EditText)findViewById(R.id.webEntreprise)).getText().toString();
                linEntreprise = ((EditText)findViewById(R.id.linkedinEntreprise)).getText().toString();

                try {
                    FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
                    String donnees = nom + "\n" + prenom + "\n" + webPerso + "\n" + linPerso + "\n" + webEntreprise + "\n" + linEntreprise;
                    fos.write(donnees.getBytes());
                    fos.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                Intent intent = new Intent(Formulaire.this,DownloadHTMLService.class);
                ArrayList<String> urls = new ArrayList<>();
                urls.add(webPerso);
                urls.add(linPerso);
                urls.add(webEntreprise);
                urls.add(linEntreprise);

                intent.putStringArrayListExtra("urls",urls);
                startService(intent);
            }
        });


        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Log.d("FOMRMULAIRE","Broadcast reçu");

                Intent intentSummary = new Intent(Formulaire.this, SummaryActivity.class);
                intentSummary.putExtra("nom", nom);
                intentSummary.putExtra("prenom", prenom);
                intentSummary.putExtra("webPerso", webPerso);
                intentSummary.putExtra("linPerso", linPerso);
                intentSummary.putExtra("webEntreprise", webEntreprise);
                intentSummary.putExtra("linEntreprise", linEntreprise);
                startActivity(intentSummary);

                Log.d("FOMULAIRE", "Intent envoyé à Summary");
            }
        };
    }



    @Override
    protected void onResume() {
        super.onResume();
        Log.d("FORMULAIRE", "onResume appelé");
        IntentFilter filter = new IntentFilter("DOWNLOAD_COMPLETE");

        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);

        Log.d("FORMULAIRE", "Receiver enregistré");
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.d("FORMULAIRE", "onPause appelé");
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        Log.d("FORMULAIRE", "Receiver désenregistré");
    }
}
